/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.surevac.servlets;

import com.surevac.Util.DataBaseConnection;
import com.surevac.Util.SendEmail;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        RequestDispatcher dispatcher = null;
        String contextStr = request.getContextPath();  // "/JavaWebApp"
        String servletPath = request.getServletPath();
        String Status = "";

        String nextPage = null;
        DataBaseConnection dbcon = new DataBaseConnection();
        java.sql.Connection con = dbcon.openConnection();
        request.setAttribute("connectionObject", con);
        if (servletPath.equals("/LoginAuthenticate")) {
            System.out.println("Inside login authenticate");
            String userName = request.getParameter("userName");
            String password = request.getParameter("password");
            String userType = request.getParameter("userType");
            boolean authentication = loginAuthentication(request, response, con, userName, password, userType);
            System.out.println("==== The authentication value is ===== " + authentication);
            if (authentication) {
                nextPage = "complaints/List";
                Status = "<div style='color:green'>Logged in successfully</div>";
            } else {
                nextPage = "/";
                Status = "<div style='color:red'>Username or password is incorrect</div>";
                if(request.getAttribute("accountStatus")!=null){
                   Status = "<div style='color:red'>Your account is not activated</div>";
                }

            }
            System.out.println("=== The next page is === " + nextPage);
            System.out.println("=== The status value is  === " + Status);



        }
        if (servletPath.equals("/forgotPassword")) {
             nextPage = "index.jsp";
            String email = request.getParameter("email");
            String tableName = request.getParameter("tableName");
            String retVal = passwordRecovery(con, tableName, "password", "email", email);
            if (retVal != null) {
                String mailMessage = " Your password is " + retVal;
                SendEmail mail = new SendEmail();
                mail.smtpMail(email, "Password Recovery", mailMessage);
                Status = "<div style='color:green'>Password has been mailed to your account</div>";
            } else {
                Status = "<div style='color:red'>User name does not exist</div>";
            }
            request.setAttribute("status", Status);
            dispatcher = request.getRequestDispatcher(nextPage);
            dispatcher.forward(request, response);

        }
        if (servletPath.equals("/activateAccount")) {
            nextPage = "index.jsp";
            Status = "<div style='color:green'>Your account has been activated</div>";
            System.out.println("====== last of log out method=======");
            request.setAttribute("status", Status);
            accountActivation(request, response, con, request.getParameter("email"), request.getParameter("dob"));
            dispatcher = request.getRequestDispatcher(nextPage);
            dispatcher.forward(request, response);
        }
        if (servletPath.equals("/logout")) {
            System.out.println("==== inside logout method====");

            nextPage = "index.jsp";
            Status = "<div style='color:green'>You have been logged out successfully</div>";
            System.out.println("====== last of log out method=======");
            request.setAttribute("status", Status);
            dispatcher = request.getRequestDispatcher(nextPage);
            dispatcher.forward(request, response);
        }
        request.setAttribute("status", Status);
//            dispatcher = request.getRequestDispatcher(nextPage);
//            dispatcher.forward(request, response);
        System.out.println("Before request dispatcher");
        request.getRequestDispatcher(nextPage).forward(request, response);
        //   response.sendRedirect(nextPage);
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public boolean loginAuthentication(HttpServletRequest request, HttpServletResponse response, Connection con, String userName, String password, String userType) {
        boolean authentication = false;
        HttpSession session = request.getSession();
        if (userType != null) {
            String sql =null;
            if(userType.equalsIgnoreCase("employees"))
            sql="Select * from "+userType+" where empCode=? and password=? limit 1;";
            else
            sql="Select * from "+userType+" where userName=? and password=? limit 1;";
            //System.out.println("=== The sql  is ==== " + sql);
            PreparedStatement pst = null;
            ResultSet rs = null;
            try {
                pst = con.prepareStatement(sql);
                pst.setString(1, userName);
                pst.setString(2, password);
//                System.out.println("==== The sql after set string is === "+sql);
//                System.out.println("==== The sql after set string is === "+pst);
                rs = pst.executeQuery();
//                System.out.println("========= The rs value is ===== "+rs);
                //System.out.println("====== Befor set attribute");
                if(userType.equalsIgnoreCase("employees"))
                session.setAttribute("user", "employees");
                else
                 session.setAttribute("user", "customer");
                //System.out.println("after set attribute");
                session.setAttribute("loginUser", rs);
                while (rs.next()) {
                     authentication = true;
                     if(!userType.equalsIgnoreCase("employees")){
                        if(rs.getString("status").equals("0")){
                            System.out.println("=========== inside ");
                            authentication=false;
                            request.setAttribute("accountStatus","0");
                        }
                    }

                    session.setAttribute("userId", rs.getString("id"));
                    session.setAttribute("userEmail", rs.getString("email"));
//                    System.out.println("==== inside while loop");
//                    System.out.println("========== The string value is ===="+rs.getString("id"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        }

        return authentication;
    }

    public int accountActivation(HttpServletRequest request, HttpServletResponse response, Connection con, String email, String dob) throws SQLException {
        Statement stmt = con.createStatement();
        String sql = "update customers set status=1 where email='" + email + "' and dob='" + dob + "'";
        //System.out.println("=========== The update sql is ========= " + sql);
        return stmt.executeUpdate(sql);
    }

    public String passwordRecovery(Connection con, String tableName, String fieldName, String whereColumn, String value) throws SQLException {
        Statement stmt = con.createStatement();
        String sql = "select " + fieldName + " from " + tableName + " where " + whereColumn + "='" + value+"'";
        //System.out.println("========= The password recovery sql is ==" + sql);
        ResultSet rs = stmt.executeQuery(sql);
        String retVal = null;
        while (rs.next()) {
            retVal = rs.getString(fieldName);
            break;
        }
        return retVal;

    }
}
